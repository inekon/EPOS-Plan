using System.Linq;
using WindowsFormsApplication1.Reporting.Dokument;

namespace WindowsFormsApplication1.Reporting.Bausteine
{
    // ---------------------------------------------------------------------------
    // Beispielbaustein - zeigt das Muster fuer alle weiteren Gewerke.
    //
    // Rund 60 Zeilen fuer ein vollstaendiges Kapitel, das in PDF, DOCX und XLSX
    // funktioniert. Kein Ausgabeformat kommt hier vor.
    //
    // Die Texte stehen bewusst als Konstanten in Texte.* und kommen dort aus den
    // Satelliten-.resx (de-DE / en-US) gemaess bestehender Projektkonvention.
    // ---------------------------------------------------------------------------

    public class WaermepumpeBaustein : IReportBaustein
    {
        public string Schluessel        => "erzeuger.waermepumpe";
        public string Bezeichnung       => Texte.Waermepumpe;
        public string Gruppe            => Texte.Gruppe_Erzeuger;
        public int    StandardSortierung => 300;

        public bool IstAnwendbar(ReportContext ctx, out string grund)
        {
            grund = null;

            if (ctx.Ergebnis == null)
            {
                grund = Texte.KeineSimulationVorhanden;
                return false;
            }

            if (!ctx.Ergebnis.Sim_Waermepumpe || ctx.Ergebnis.Waermepumpe == null)
            {
                grund = Texte.KeineWaermepumpeSimuliert;
                return false;
            }

            return true;
        }

        public void Schreibe(ReportDocument doc, ReportContext ctx, BausteinOptionen opt)
        {
            ErgebnisWaermepumpeModel wp = ctx.Ergebnis.Waermepumpe;
            WaermepumpeStamm stamm = ctx.Erzeuger.WP;

            ReportAbschnitt a = doc.NeuerAbschnitt(Texte.Waermepumpe, ebene: 1);

            // -- Einleitender Text -------------------------------------------------
            if (stamm != null)
                a.Text(string.Format(Texte.WP_Einleitung,
                                     Werteformat.Aktuell.Text(stamm.Firma),
                                     Werteformat.Aktuell.Text(stamm.Name),
                                     Werteformat.Aktuell.ZahlMitEinheit(stamm.Nennleistung, "kW")));

            // -- Auslegungsdaten aus dem Stamm ------------------------------------
            if (stamm != null && opt.Tiefe != Detailtiefe.Kurz)
            {
                a.Kennwerte(Texte.WP_Auslegung, spalten: 2)
                    .Wert(Texte.Hersteller,       stamm.Firma)
                    .Wert(Texte.Typbezeichnung,   stamm.Name)
                    .Wert(Texte.Bauart,           stamm.Bauart)
                    .Wert(Texte.Aufstellung,      stamm.Aufstellung)
                    .Wert(Texte.Nennleistung,     stamm.Nennleistung, "kW")
                    .Wert(Texte.MaxVorlauf,       stamm.MaxVorlauf,   "°C")
                    .Wert(Texte.Regelung,         stamm.Regelung)
                    .Wert(Texte.Kuehlleistung,    stamm.Kuehlleistung, "kW");
            }

            // -- Ergebnisse der Simulation ----------------------------------------
            a.Kennwerte(Texte.WP_Ergebnis, spalten: 2)
                .Wert(Texte.Waermeproduktion,      wp.Waermeproduktion_WP,      "MWh/a")
                .Wert(Texte.Stromverbrauch,        wp.Stromverbrauch_WP,        "MWh/a")
                .Wert(Texte.StromverbrauchHeizstab, wp.Stromverbrauch_Heizstab, "MWh/a")
                .Wert(Texte.Waermebedarfsdeckung,  wp.Waermebedarfsdeckung, "%",
                      hervorgehoben: true)
                .Wert(Texte.Vollbenutzungsstunden, wp.Vollbenutzungsstunden,    "h/a", "N0")
                .Wert(Texte.Bivalenzpunkt,         wp.Bivalenzpunkt,            "°C")
                .Wert(Texte.MinSpitzenkessel,      wp.Min_Spitzenkesselleistung, "kW")
                .Wert(Texte.KapazitaetPuffer,      wp.Kapazitaet_Pufferspeicher, "kWh", "N0");

            // Restwaermebedarf nur nennen, wenn er nennenswert ist - sonst irritiert
            // eine 0-Zeile im Kundendokument mehr als sie hilft.
            if (wp.Restwaermebedarf > 0.05)
                a.Hinweis(string.Format(Texte.WP_Restbedarf,
                          Werteformat.Aktuell.ZahlMitEinheit(wp.Restwaermebedarf, "MWh/a")));

            // -- Modultabelle -------------------------------------------------------
            if (opt.ModultabellenAnzeigen && wp.Module != null && wp.Module.Count > 0)
            {
                a.Tabelle(Texte.WP_Module)
                    .Spalte(Texte.Modul,               Ausrichtung.Links, breitenAnteil: 2.0)
                    .Spalte(Texte.Leistung,            "N1", "kW")
                    .Spalte(Texte.Waermeproduktion,    "N1", "MWh/a")
                    .Spalte(Texte.Stromverbrauch,      "N1", "MWh/a")
                    .Spalte(Texte.Heizstab,            "N1", "MWh/a")
                    .Spalte(Texte.Betriebsstunden,     "N0", "h/a")
                    .Zeilen(wp.Module, m => new object[]
                    {
                        m.Modul,
                        m.Leistung,
                        m.Waermeproduktion,
                        m.Stromverbrauch,
                        m.Heizstab,
                        m.Betriebsstunden
                    })
                    .MitSummenzeile();
            }

            // -- Kennlinie ----------------------------------------------------------
            if (opt.Tiefe == Detailtiefe.Ausfuehrlich
                && stamm != null && stamm.Kennlinie.Count > 0)
            {
                a.Tabelle(Texte.WP_Kennlinie)
                    .Spalte(Texte.Vorlauftemperatur,  "N0", "°C")
                    .Spalte(Texte.Quelltemperatur,    "N0", "°C")
                    .Spalte(Texte.COP,                "N2")
                    .Spalte(Texte.Waermeleistung,     "N1", "kW")
                    .Zeilen(stamm.Kennlinie.OrderBy(k => k.Vorlauf).ThenBy(k => k.Quelltemperatur),
                            k => new object[] { k.Vorlauf, k.Quelltemperatur, k.COP, k.PTherm });
            }

            // -- Diagramme ----------------------------------------------------------
            if (opt.DiagrammeAnzeigen)
            {
                a.Diagramm("WP_Kennlinie",  Texte.Abb_WP_Kennlinie);
                a.Diagramm("WP_Ganglinie",  Texte.Abb_WP_Ganglinie);
            }

            // -- Optionaler Freitext des Anwenders ----------------------------------
            string anmerkung = opt.Freitext("wp.anmerkung");
            if (!string.IsNullOrWhiteSpace(anmerkung))
                a.Text(anmerkung);
        }
    }
}
