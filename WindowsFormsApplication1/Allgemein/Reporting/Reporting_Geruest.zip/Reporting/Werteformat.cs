using System;
using System.Globalization;

namespace WindowsFormsApplication1.Reporting
{
    // ---------------------------------------------------------------------------
    // Zentrale Formatierung ALLER Werte, die in einen Bericht gehen.
    //
    // Zwei Regeln, die hier durchgesetzt werden:
    //
    // 1) Massgeblich ist die BERICHTSSPRACHE, nicht die UI-Sprache. Sonst steht im
    //    englischen Bericht "1.234,5".
    // 2) Fehlende Werte bleiben fehlend. null wird zu "-", niemals zu "0,0".
    //    In einem Auslegungsnachweis oder Foerderantrag ist das kein Detail:
    //    eine still gerenderte 0 sieht plausibel aus und ist trotzdem falsch.
    //
    // Kein Renderer und kein Baustein formatiert selbst.
    // ---------------------------------------------------------------------------

    public class Werteformat
    {
        /// <summary>Platzhalter fuer "kein Wert vorhanden".</summary>
        public const string OhneWert = "—";   // Geviertstrich

        private readonly CultureInfo _kultur;

        /// <summary>Wird vom ReportService je Lauf gesetzt. Bausteine greifen ueber
        /// die Convenience-Ueberladungen im Dokumentmodell darauf zu.</summary>
        public static Werteformat Aktuell { get; private set; } = new Werteformat("de-DE");

        public static IDisposable Setze(string sprache)
        {
            Werteformat vorher = Aktuell;
            Aktuell = new Werteformat(sprache);
            return new Ruecksetzer(() => Aktuell = vorher);
        }

        public Werteformat(string sprache)
        {
            _kultur = CultureInfo.GetCultureInfo(string.IsNullOrWhiteSpace(sprache)
                                                 ? "de-DE" : sprache);
        }

        public CultureInfo Kultur => _kultur;

        // -- Zahlen ---------------------------------------------------------------

        public string Zahl(double? wert, string format = "N1")
        {
            if (!wert.HasValue || double.IsNaN(wert.Value) || double.IsInfinity(wert.Value))
                return OhneWert;
            return wert.Value.ToString(format ?? "N1", _kultur);
        }

        public string Zahl(int? wert, string format = "N0")
            => wert.HasValue ? wert.Value.ToString(format ?? "N0", _kultur) : OhneWert;

        /// <summary>Zahl mit Einheit, z.B. "12,4 kW". Ohne Wert nur der Platzhalter,
        /// ohne angehaengte Einheit - "- kW" liest sich wie ein Fehler.</summary>
        public string ZahlMitEinheit(double? wert, string einheit, string format = "N1")
        {
            string z = Zahl(wert, format);
            if (z == OhneWert || string.IsNullOrEmpty(einheit)) return z;
            return z + " " + einheit;      // geschuetztes Leerzeichen
        }

        public string Prozent(double? wert, string format = "N1")
            => ZahlMitEinheit(wert, "%", format);

        // -- Sonstiges ------------------------------------------------------------

        public string Datum(DateTime? wert, string format = "d")
            => wert.HasValue && wert.Value != DateTime.MinValue
               ? wert.Value.ToString(format, _kultur)
               : OhneWert;

        public string DatumZeit(DateTime? wert)
            => wert.HasValue && wert.Value != DateTime.MinValue
               ? wert.Value.ToString("g", _kultur)
               : OhneWert;

        public string JaNein(bool wert) => wert ? Texte.Ja : Texte.Nein;

        public string Text(string wert)
            => string.IsNullOrWhiteSpace(wert) ? OhneWert : wert.Trim();

        /// <summary>Zelle einer Tabelle fuer die textbasierten Renderer (PDF/DOCX).
        /// Der XLSX-Renderer verwendet stattdessen den Rohwert, damit in Excel
        /// gerechnet werden kann.</summary>
        public string Zelle(object rohwert, bool istZahl, string format)
        {
            if (rohwert == null) return OhneWert;

            if (istZahl)
            {
                if (rohwert is double d)  return Zahl(d, format);
                if (rohwert is float f)   return Zahl(f, format);
                if (rohwert is decimal m) return Zahl((double)m, format);
                if (rohwert is int i)     return Zahl(i, format ?? "N0");
                if (rohwert is long l)    return Zahl(l, format ?? "N0");
            }

            if (rohwert is DateTime dt) return Datum(dt);
            if (rohwert is bool b)      return JaNein(b);

            return Text(rohwert.ToString());
        }

        private sealed class Ruecksetzer : IDisposable
        {
            private readonly Action _aktion;
            public Ruecksetzer(Action aktion) { _aktion = aktion; }
            public void Dispose() { _aktion(); }
        }
    }
}
