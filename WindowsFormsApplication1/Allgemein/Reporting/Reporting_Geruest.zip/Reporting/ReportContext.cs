using System;
using System.Collections.Generic;

namespace WindowsFormsApplication1.Reporting
{
    // ---------------------------------------------------------------------------
    // Fachdatenmodell fuer die Berichterstellung.
    //
    // WICHTIG: ErgebnisModel wird REFERENZIERT, nicht kopiert. Es ist laut seinem
    // eigenen Kommentarkopf bereits fuer Auswertungen/Berichte gebaut, liegt in
    // Tab_Ergebnis* persistiert vor und wird mit einem Aufruf geladen:
    //
    //     ctx.Ergebnis = new ErgebnisCtrl().Load(idProjekt);
    //
    // Damit entfaellt der gesamte Simulations-Teil des ContextBuilders, und es gibt
    // keine Drift zwischen zwei parallelen Ergebnismodellen.
    //
    // Neue Bloecke werden konsequent NULLABLE angelegt (double?), damit "kein Wert"
    // von "0" unterscheidbar bleibt. Die bestehenden Modelle bleiben unveraendert;
    // dort entscheiden die Sim_*-Flags, ob ein Wert ueberhaupt gilt.
    // ---------------------------------------------------------------------------

    public class ReportContext
    {
        public MetaBlock     Meta     = new MetaBlock();
        public ProjektBlock  Projekt  = new ProjektBlock();
        public StandortBlock Standort = new StandortBlock();

        /// <summary>Ein Projekt kann mehrere Gebaeude haben (ProjektGebaeudeModel.items).</summary>
        public List<GebaeudeBlock> Gebaeude = new List<GebaeudeBlock>();

        /// <summary>Anlagenkonfiguration aus WErzeugerModel - haelt die Verweise auf
        /// alle Komponenten und die Betriebsparameter.</summary>
        public AnlageBlock   Anlage   = new AnlageBlock();

        /// <summary>Stammdaten der eingesetzten Komponenten, benannt zugreifbar.</summary>
        public ErzeugerBlock Erzeuger = new ErzeugerBlock();
        public SpeicherBlock Speicher = new SpeicherBlock();

        /// <summary>Simulationsergebnis, unveraendert aus ErgebnisCtrl.Load().
        /// null = fuer dieses Projekt liegt keine Simulation vor.</summary>
        public ErgebnisModel Ergebnis;

        /// <summary>Im Builder aus Emissionsfaktoren (Kessel/BHKW) und Verbraeuchen
        /// (Ergebnis) gerechnet.</summary>
        public EmissionBlock Emission;

        /// <summary>Noch nicht vorhanden - siehe Feldmapping, Abschnitt 3.
        /// Bleibt null, bis das VDI-2067-Rechenmodell existiert.</summary>
        public WirtschaftBlock Wirtschaft;

        /// <summary>Vom Anwender im Report-Center erfasste Freitexte.</summary>
        public Dictionary<string, string> Freitexte = new Dictionary<string, string>();

        public bool HatSimulation => Ergebnis != null;
    }

    public class MetaBlock
    {
        public DateTime  Berichtsdatum = DateTime.Now;
        public string    ErzeugtVon;
        public string    WPPlanVersion;
        public string    Sprache = "de-DE";
        /// <summary>ErgebnisModel.Zeitstempel. Gehoert in jeden Bericht - pro Projekt
        /// wird nur der letzte Simulationslauf gespeichert.</summary>
        public DateTime? Simulationsstand;
    }

    public class ProjektBlock
    {
        public int      ID;
        public string   Bezeichnung;      // ProjektModel.m_szProjektname
        public string   Kunde;            // m_szKunde  (Freitext, keine strukturierte Adresse)
        public string   Bearbeiter;       // m_szBearbeiter
        public string   Beschreibung;     // m_szBeschreibung
        public DateTime? Erstellt;        // m_Erstelldatum
        public DateTime? Geaendert;       // m_Aenderungsdatum
        public double?  Netzverluste;     // OFFEN: ProjektModel.m_nNetzverluste
                                          //        oder KonfigurationModel.m_Netzverluste?
        public string   NetzverlusteEinheit;
    }

    public class StandortBlock
    {
        public string  Klimaregion;              // ProjektModel.m_szKlimaregion
        public double? Breite;                   // KlimaregionModel.Latitude
        public double? Laenge;                   // KlimaregionModel.Longitude
        public string  Details;
        /// <summary>NICHT als Feld vorhanden. Entweder aus den Stundenwerten in
        /// KlimadatenModel.m_nTemperatur abgeleitet (dann Verfahren dokumentieren -
        /// die Zahl landet in Auslegungsnachweisen) oder als Freitext erfasst.</summary>
        public double? NormAussentemperatur;
        public double? GlobalstrahlungJahr;      // Summe ueber KlimadatenModel
    }

    public class GebaeudeBlock
    {
        public string  Name;                 // ProjektGebaeudeModel.Gebaeudename
        public string  Art;                  // Gebaeudeart
        public string  Baualtersklasse;
        public string  Typ;
        public double? WohnflaecheGesamt;
        public double? Bewohner;
        public double? Raumhoehe;
        public double? Luftwechselrate;
        public double? RaumsolltemperaturTag;
        public double? Waermebedarf;
        public double? SpezWaermeverbrauch;
        public double? WWBedarf;
        public double? Jahresnutzungsgrad;
        public bool    DezentralWarmwasser;

        // Huellflaechen und U-Werte (Platzhalternamen bewusst ASCII, siehe Feldmapping 4.4)
        public double? UWertAussenwand;
        public double? UWertFenster;
        public double? UWertDachflaeche;
        public double? UWertGrundflaeche;
        public double? FlaecheAussenwand;
        public double? FensterflaecheGesamt;
        public double? Dachflaeche;
        public double? Grundflaeche;
    }

    public class AnlageBlock
    {
        public string  Bezeichner;
        public string  Betriebsart;
        public int?    Vorlauf;
        public int?    Ruecklauf;
        public bool    BivalenterBetrieb;
        public double? Abschaltpunkt;
        public bool    Heizstab;
        public double? Grenzleistung;
        public double? PVLeistung;
        public int?    Neigung;
        public int?    Azimut;
        public int?    Kollektormodulanzahl;
        public int?    Solaranteil;
        public bool    Sperrung;
        public int?    SperrzeitVon;
        public int?    SperrzeitBis;
    }

    public class ErzeugerBlock
    {
        // Benannte Zugriffe. null = im Projekt nicht vorhanden.
        public WaermepumpeStamm  WP;
        public BhkwStamm         BHKW;
        public KesselStamm       Kessel;
        public SolarthermieStamm Solarthermie;
        public PvStamm           PV;

        public bool HatWP           => WP != null;
        public bool HatBHKW         => BHKW != null;
        public bool HatKessel       => Kessel != null;
        public bool HatSolarthermie => Solarthermie != null;
        public bool HatPV           => PV != null;
    }

    public class WaermepumpeStamm
    {
        public string  Name;            // WPModel.WPName
        public string  Firma;
        public string  Typ;
        public string  Bauart;
        public string  Aufstellung;
        public string  Regelung;
        public string  Leistungsstufen;
        public int?    Baujahr;
        public double? Nennleistung;
        public double? MaxPTherm;
        public double? Kuehlleistung;
        public int?    MinVorlauf;
        public int?    MaxVorlauf;
        /// <summary>Kennlinienpunkte aus KenndatenModel (Vorlauf/Quelltemp./COP/PTherm).
        /// KenndatenModel ist internal - deshalb hier auf einen eigenen Typ abgebildet.</summary>
        public List<Kennlinienpunkt> Kennlinie = new List<Kennlinienpunkt>();

        public bool HatKuehlung => Kuehlleistung.HasValue && Kuehlleistung.Value > 0;
    }

    public class Kennlinienpunkt
    {
        public int    Vorlauf;
        public int    Quelltemperatur;
        public double COP;
        public double PTherm;
    }

    public class BhkwStamm
    {
        public string  Bezeichner;
        public string  Firma;
        public string  Motortyp;
        public double? PTherm;
        public double? PEl;
        public double? Wirkungsgrad;
        public int?    Vorlauf;
        public int?    Ruecklauf;
        public double? Grenzleistung;
        public int?    Nutzungsdauer;
        // Emissionsfaktoren - Einheit im Quellmodell nicht dokumentiert, vor Nutzung pruefen
        public double? CO2, SO2, NOx, CO, Staub;
    }

    public class KesselStamm
    {
        public string  Name;
        public string  Firma;
        public double? PTherm;
        public bool    Brennwert;
        public double? WirkungsgradGas;
        public double? WirkungsgradOel;
        public double? Betriebsbereitschaftverlust;
        public int?    Vorlauf;
        public int?    Ruecklauf;
        public double? Nutzungsdauer;
        public double? CO2, SO2, NOx, CO, Staub;
    }

    public class SolarthermieStamm
    {
        public string  Kollektorname;
        public string  Firma;
        public string  Kollektortyp;
        public double? Modulflaeche;
        public double? Aperturflaeche;
        public double? h0, k1, k2;
    }

    public class PvStamm
    {
        public string  Name;
        public string  Firma;
        public double? Leistung;
        public double? Wirkungsgrad;
        public double? TempCoeffPmax;
        public double? TNOCT;
        public double? Laenge;
        public double? Breite;
    }

    public class SpeicherBlock
    {
        public PufferStamm Puffer;
        public StromspeicherStamm Strom;

        public bool HatPuffer => Puffer != null;
        public bool HatStromspeicher => Strom != null;
    }

    public class PufferStamm
    {
        public string  Name;
        public string  Firma;
        public string  Speichertyp;
        public double? Gesamtvolumen;
        public double? Betriebsbereitschaftverlust;
    }

    public class StromspeicherStamm
    {
        public string  Bezeichner;
        public string  Typ;
        public double? Energie;
        public double? Leistung;
        public double? Degradation;
    }

    /// <summary>Im ContextBuilder gerechnet: Emissionsfaktoren der Erzeuger mal
    /// Brennstoffverbraeuche aus dem Ergebnis, plus Netzbezug mal Strommix-Faktor.</summary>
    public class EmissionBlock
    {
        public double? CO2Jahr;          // t/a
        public double? CO2Waermeerzeugung;
        public double? CO2Netzbezug;
        public double? StrommixFaktor;   // g/kWh - Quelle und Jahr dokumentieren
        public double? SO2Jahr, NOxJahr, COJahr, StaubJahr;
    }

    /// <summary>Platzhalter. Es gibt derzeit weder Rechenmodell noch Eingaben
    /// (Energiepreise, Zinssatz, Preissteigerung, Betrachtungszeitraum).
    /// Siehe Feldmapping Abschnitt 3 - eigenes Vorprojekt.</summary>
    public class WirtschaftBlock
    {
        public double? Investition;
        public double? AnnuitaetGesamt;
        public double? Amortisationszeit;
        public double? Betrachtungszeitraum;
        public double? Zinssatz;
        public double? Waermegestehungskosten;   // ct/kWh
    }
}
