using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using WindowsFormsApplication1.Reporting.Dokument;

namespace WindowsFormsApplication1.Reporting
{
    // ---------------------------------------------------------------------------
    // Ein Baustein ist ein Kapitel des Berichts. Er schreibt ausschliesslich in das
    // format-neutrale ReportDocument und kennt kein Ausgabeformat.
    //
    // Bausteine sind CODE, keine Dateien. Die Datenbank haelt nur, was
    // konfigurierbar ist: Aktiv-Status, Sortierung, Bezeichnungs-Override.
    // ---------------------------------------------------------------------------

    public interface IReportBaustein
    {
        /// <summary>Stabiler Schluessel, z.B. "erzeuger.waermepumpe".
        /// Wird in Bericht_Profil gespeichert - nach Auslieferung nicht mehr aendern.</summary>
        string Schluessel { get; }

        /// <summary>Anzeigename, aus den Satelliten-.resx.</summary>
        string Bezeichnung { get; }

        /// <summary>Gruppe fuer die Darstellung im Report-Center.</summary>
        string Gruppe { get; }

        int StandardSortierung { get; }

        /// <summary>Liefert false, wenn im Projekt keine Datengrundlage vorliegt.
        /// Der Grund wird im Report-Center hinter dem deaktivierten Kapitel angezeigt -
        /// besser als ein leerer Abschnitt im Kundendokument.</summary>
        bool IstAnwendbar(ReportContext ctx, out string grund);

        void Schreibe(ReportDocument doc, ReportContext ctx, BausteinOptionen opt);
    }

    public class BausteinOptionen
    {
        public bool DiagrammeAnzeigen = true;
        public bool ModultabellenAnzeigen = true;
        public Detailtiefe Tiefe = Detailtiefe.Standard;
        public Dictionary<string, string> Freitexte = new Dictionary<string, string>();

        public string Freitext(string schluessel)
            => Freitexte != null && Freitexte.TryGetValue(schluessel, out string t) ? t : null;
    }

    public enum Detailtiefe { Kurz, Standard, Ausfuehrlich }

    /// <summary>Findet alle IReportBaustein-Implementierungen per Reflection und
    /// verbindet sie mit ihrer Konfiguration aus Bericht_Baustein.</summary>
    public class BausteinRegistry
    {
        private readonly List<IReportBaustein> _bausteine = new List<IReportBaustein>();

        public IReadOnlyList<IReportBaustein> Alle => _bausteine;

        public BausteinRegistry()
        {
            Type ziel = typeof(IReportBaustein);

            IEnumerable<Type> typen = Assembly.GetExecutingAssembly()
                .GetTypes()
                .Where(t => ziel.IsAssignableFrom(t)
                            && !t.IsInterface
                            && !t.IsAbstract
                            && t.GetConstructor(Type.EmptyTypes) != null);

            foreach (Type t in typen)
                _bausteine.Add((IReportBaustein)Activator.CreateInstance(t));

            _bausteine.Sort((a, b) => a.StandardSortierung.CompareTo(b.StandardSortierung));

            PruefeSchluesselEindeutig();
        }

        public IReportBaustein Finde(string schluessel)
            => _bausteine.FirstOrDefault(b =>
                   string.Equals(b.Schluessel, schluessel, StringComparison.OrdinalIgnoreCase));

        /// <summary>Bausteine mit Verfuegbarkeitspruefung - Grundlage der Kapitelliste
        /// im Report-Center.</summary>
        public List<BausteinStatus> Ermittle(ReportContext ctx)
        {
            List<BausteinStatus> liste = new List<BausteinStatus>();

            foreach (IReportBaustein b in _bausteine)
            {
                string grund;
                bool anwendbar;

                try
                {
                    anwendbar = b.IstAnwendbar(ctx, out grund);
                }
                catch (Exception ex)
                {
                    // Ein fehlerhafter Baustein darf nie die ganze Kapitelliste kippen.
                    anwendbar = false;
                    grund = ex.Message;
                }

                liste.Add(new BausteinStatus
                {
                    Baustein = b,
                    Anwendbar = anwendbar,
                    Grund = grund
                });
            }

            return liste;
        }

        private void PruefeSchluesselEindeutig()
        {
            var doppelt = _bausteine.GroupBy(b => b.Schluessel, StringComparer.OrdinalIgnoreCase)
                                    .Where(g => g.Count() > 1)
                                    .Select(g => g.Key)
                                    .ToList();

            if (doppelt.Count > 0)
                throw new InvalidOperationException(
                    "Doppelte Baustein-Schluessel: " + string.Join(", ", doppelt));
        }
    }

    public class BausteinStatus
    {
        public IReportBaustein Baustein;
        public bool Anwendbar;
        public string Grund;
    }
}
