# Grundgerüst Berichtsmodul — Einbauhinweise

Diese Dateien gehören nach `WindowsFormsApplication1\Allgemein\Reporting\`.
Sie sind der Kern aus Fassung 2 des Konzepts: das format-neutrale Dokumentmodell
plus ein vollständiger Beispielbaustein.

```
Allgemein/Reporting/
├─ Dokument/ReportDocument.cs      Dokumentmodell + Fluent-API für Bausteine
├─ Werteformat.cs                  zentrale Formatierung, Kultur- und null-Regeln
├─ ReportContext.cs                Fachdatenmodell, referenziert ErgebnisModel
├─ IReportBaustein.cs              Baustein-Schnittstelle + Registry (Reflection)
├─ Bausteine/WaermepumpeBaustein.cs Beispielbaustein, ~60 Zeilen für ein Kapitel
└─ Renderer/IReportRenderer.cs     Renderer-Schnittstelle
```

## Was noch fehlt, damit es kompiliert

**`Texte.cs`** — die Klasse gibt es noch nicht. Sie hält alle sichtbaren Zeichenketten
und sollte aus den Satelliten-`.resx` (`de-DE`, `en-US`) bedient werden, wie im Projekt
üblich. Für einen ersten Durchstich genügt eine Klasse mit Konstanten; die
Umstellung auf `.resx` ist danach mechanisch. Gebraucht werden unter anderem:

`Ja`, `Nein`, `Waermepumpe`, `Gruppe_Erzeuger`, `KeineSimulationVorhanden`,
`KeineWaermepumpeSimuliert`, `WP_Einleitung` (Formatstring mit 3 Platzhaltern),
`WP_Auslegung`, `WP_Ergebnis`, `WP_Module`, `WP_Kennlinie`, `WP_Restbedarf`
(Formatstring mit 1 Platzhalter), `Hersteller`, `Typbezeichnung`, `Bauart`,
`Aufstellung`, `Nennleistung`, `MaxVorlauf`, `Regelung`, `Kuehlleistung`,
`Waermeproduktion`, `Stromverbrauch`, `StromverbrauchHeizstab`,
`Waermebedarfsdeckung`, `Vollbenutzungsstunden`, `Bivalenzpunkt`,
`MinSpitzenkessel`, `KapazitaetPuffer`, `Modul`, `Leistung`, `Heizstab`,
`Betriebsstunden`, `Vorlauftemperatur`, `Quelltemperatur`, `COP`,
`Waermeleistung`, `Abb_WP_Kennlinie`, `Abb_WP_Ganglinie`.

**`ReportTheme`** — als Klasse noch nicht enthalten, wird von `IReportRenderer`
referenziert. Struktur steht in Konzept Kapitel 5.3 (JSON: Logo, Farben, Schrift,
Seitenränder, Kopf-/Fußzeile).

**`ContextBuilder`** — füllt den `ReportContext` aus den vorhandenen Controllern.
Der Simulationsteil ist ein Einzeiler:

```csharp
ctx.Ergebnis = new ErgebnisCtrl().Load(idProjekt);
ctx.Meta.Simulationsstand = ctx.Ergebnis?.Zeitstempel;
```

Die Zuordnung aller übrigen Felder steht in `Konzept_Berichterstellung_Feldmapping.md`,
Abschnitt 2.

## Entwurfsentscheidungen, die im Code stecken

**Bausteine kennen kein Ausgabeformat.** `WaermepumpeBaustein` schreibt Abschnitte,
Kennwertblöcke, Tabellen und Diagrammverweise — daraus wird PDF, Word und Excel.
Ein neues Gewerk kostet damit einmal Arbeit, nicht dreimal.

**Tabellen führen Rohwerte, keine Strings.** `TabelleBlock.Zeilen` enthält `object[]`
mit echten `double`-Werten; das Spaltenformat steuert Anzeige (PDF/DOCX) und
Zellformat (XLSX). Ohne das kann in Excel niemand weiterrechnen, und genau dafür
ist das Format da.

**`null` wird `—`, nie `0,0`.** In `Werteformat` durchgesetzt. Eine still gerenderte
Null in einem Auslegungsnachweis sieht plausibel aus und ist trotzdem falsch. Bei
Erzeugern entscheiden zusätzlich die `Sim_*`-Flags aus `ErgebnisModel`, nicht der
Zahlenwert — „simuliert, aber nicht gelaufen" und „gar nicht vorhanden" sind
verschiedene Aussagen.

**`ErgebnisModel` wird referenziert, nicht kopiert.** Es ist laut eigenem
Kommentarkopf bereits für Berichte gebaut. Zwei parallele Ergebnismodelle würden
über kurz oder lang auseinanderlaufen.

**Ein fehlerhafter Baustein kippt nicht die Kapitelliste.** `BausteinRegistry.Ermittle`
fängt Ausnahmen aus `IstAnwendbar` ab und zeigt sie als Grund an.

**Baustein-Schlüssel sind stabil.** Sie landen in `Bericht_Profil` — nach der ersten
Auslieferung nicht mehr ändern. Die Registry prüft beim Start auf Doppelte.

## Nächster sinnvoller Schritt

Der Spike aus Konzept Stufe 0: QuestPDF (oder PDFsharp/MigraDoc) auf **x86** mit
einem Beispieldokument — Deckblatt, Kopf-/Fußzeile, Tabelle über zwei Seiten mit
wiederholter Kopfzeile, eingebettetes PNG. Das klärt die native-Skia-Frage und die
Wahl der Layout-Engine, bevor Arbeit darauf aufbaut. Ein bis zwei Tage.
