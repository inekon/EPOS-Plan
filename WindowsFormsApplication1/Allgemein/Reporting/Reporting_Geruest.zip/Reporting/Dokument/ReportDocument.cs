using System;
using System.Collections.Generic;
using System.Linq;

namespace WindowsFormsApplication1.Reporting.Dokument
{
    // ---------------------------------------------------------------------------
    // Format-neutrales Dokumentmodell.
    //
    // Bausteine schreiben ausschliesslich hier hinein und wissen nicht, ob daraus
    // PDF, DOCX oder XLSX wird. Jeder zusaetzliche Blocktyp kostet Arbeit in DREI
    // Renderern - das Modell deshalb bewusst klein halten.
    //
    // Freie Positionierung und beliebige Verschachtelung sind nicht vorgesehen und
    // werden von einem Ingenieurbericht auch nicht gebraucht.
    // ---------------------------------------------------------------------------

    public enum TextStil { Standard, Hinweis, Klein }
    public enum Ausrichtung { Links, Rechts, Zentriert }

    public class DokumentKopf
    {
        public string Titel;
        public string Untertitel;
        public string Projektname;
        public string Kunde;
        public string Bearbeiter;
        public DateTime Berichtsdatum = DateTime.Now;
        public DateTime? Simulationsstand;   // ErgebnisModel.Zeitstempel
        public string Sprache = "de-DE";
        public string ThemeName;
        public string WPPlanVersion;
    }

    public class ReportDocument
    {
        public DokumentKopf Kopf = new DokumentKopf();
        public List<ReportAbschnitt> Abschnitte = new List<ReportAbschnitt>();

        public ReportAbschnitt NeuerAbschnitt(string titel, int ebene = 1, string anker = null)
        {
            ReportAbschnitt a = new ReportAbschnitt
            {
                Titel = titel,
                Ebene = ebene,
                Anker = anker ?? AnkerAus(titel, Abschnitte.Count)
            };
            Abschnitte.Add(a);
            return a;
        }

        private static string AnkerAus(string titel, int index)
        {
            string roh = (titel ?? "abschnitt").ToLowerInvariant()
                .Replace("ä", "ae").Replace("ö", "oe").Replace("ü", "ue").Replace("ß", "ss");
            char[] gefiltert = roh.Select(c => char.IsLetterOrDigit(c) ? c : '-').ToArray();
            return new string(gefiltert).Trim('-') + "-" + index;
        }
    }

    public class ReportAbschnitt
    {
        public string Titel;
        public int    Ebene = 1;          // 1..3
        public string Anker;
        public List<ReportBlock> Bloecke = new List<ReportBlock>();

        // -- Fluent-API fuer Bausteine -------------------------------------------

        public ReportAbschnitt Text(string text, TextStil stil = TextStil.Standard)
        {
            if (!string.IsNullOrWhiteSpace(text))
                Bloecke.Add(new TextBlock { Text = text, Stil = stil });
            return this;
        }

        public ReportAbschnitt Hinweis(string text) => Text(text, TextStil.Hinweis);

        public KennwertBlock Kennwerte(string titel = null, int spalten = 2)
        {
            KennwertBlock b = new KennwertBlock { Titel = titel, Spalten = spalten };
            Bloecke.Add(b);
            return b;
        }

        public TabelleBlock Tabelle(string titel = null)
        {
            TabelleBlock b = new TabelleBlock { Titel = titel };
            Bloecke.Add(b);
            return b;
        }

        public ReportAbschnitt Diagramm(string chartName, string beschriftung = null,
                                        double breiteAnteil = 1.0)
        {
            Bloecke.Add(new DiagrammBlock
            {
                ChartName = chartName,
                Beschriftung = beschriftung,
                BreiteAnteil = breiteAnteil
            });
            return this;
        }

        public ReportAbschnitt Aufzaehlung(IEnumerable<string> punkte, bool nummeriert = false)
        {
            List<string> liste = punkte?.Where(p => !string.IsNullOrWhiteSpace(p)).ToList();
            if (liste != null && liste.Count > 0)
                Bloecke.Add(new AufzaehlungBlock { Punkte = liste, Nummeriert = nummeriert });
            return this;
        }

        public ReportAbschnitt Seitenumbruch()
        {
            Bloecke.Add(new SeitenumbruchBlock());
            return this;
        }

        /// <summary>True, wenn der Abschnitt ausser Ueberschrift nichts enthaelt.
        /// Der ReportService verwirft solche Abschnitte vor dem Rendern.</summary>
        public bool IstLeer => Bloecke.Count == 0
                            || Bloecke.All(b => b is SeitenumbruchBlock);
    }

    // -- Bloecke -----------------------------------------------------------------

    public abstract class ReportBlock { }

    public class TextBlock : ReportBlock
    {
        public string Text;
        public TextStil Stil = TextStil.Standard;
    }

    /// <summary>Label - Wert - Einheit, ein- bis dreispaltig gesetzt.
    /// Der haeufigste Block; im XLSX-Renderer landet er auf dem Uebersichtsblatt.</summary>
    public class KennwertBlock : ReportBlock
    {
        public string Titel;
        public int Spalten = 2;
        public List<Kennwert> Werte = new List<Kennwert>();

        public KennwertBlock Wert(string label, string wert, string einheit = null,
                                 bool hervorgehoben = false)
        {
            Werte.Add(new Kennwert
            {
                Label = label,
                Wert = wert,
                Einheit = einheit,
                Hervorgehoben = hervorgehoben
            });
            return this;
        }

        public KennwertBlock Wert(string label, double? wert, string einheit = null,
                                  string format = "N1", bool hervorgehoben = false)
            => Wert(label, Werteformat.Aktuell.Zahl(wert, format), einheit, hervorgehoben);

        public KennwertBlock Wert(string label, int? wert, string einheit = null,
                                  bool hervorgehoben = false)
            => Wert(label, Werteformat.Aktuell.Zahl(wert, "N0"), einheit, hervorgehoben);

        public KennwertBlock Wert(string label, DateTime? wert, bool hervorgehoben = false)
            => Wert(label, Werteformat.Aktuell.Datum(wert), null, hervorgehoben);

        public KennwertBlock Wert(string label, bool wert, bool hervorgehoben = false)
            => Wert(label, Werteformat.Aktuell.JaNein(wert), null, hervorgehoben);
    }

    public class Kennwert
    {
        public string Label;
        public string Wert;
        public string Einheit;
        public bool   Hervorgehoben;
    }

    /// <summary>Tabelle mit typisierten Spalten. Zeilen fuehren ROHWERTE, damit der
    /// XLSX-Renderer echte Zahlen schreiben kann - sonst kann der Anwender in Excel
    /// nicht weiterrechnen, und genau dafuer ist das Format da.</summary>
    public class TabelleBlock : ReportBlock
    {
        public string Titel;
        public List<Spalte> Spalten = new List<Spalte>();
        public List<object[]> Zeilen = new List<object[]>();
        public bool SummenzeileAnzeigen;

        public TabelleBlock Spalte(string ueberschrift, Ausrichtung ausrichtung = Ausrichtung.Links,
                                   double breitenAnteil = 1.0)
        {
            Spalten.Add(new Spalte
            {
                Ueberschrift = ueberschrift,
                Ausrichtung = ausrichtung,
                BreitenAnteil = breitenAnteil
            });
            return this;
        }

        /// <summary>Zahlenspalte: Format und Einheit steuern Anzeige (PDF/DOCX) und
        /// Zellformat (XLSX).</summary>
        public TabelleBlock Spalte(string ueberschrift, string format, string einheit = null,
                                   double breitenAnteil = 1.0)
        {
            Spalten.Add(new Spalte
            {
                Ueberschrift = ueberschrift,
                Ausrichtung = Ausrichtung.Rechts,
                Format = format,
                Einheit = einheit,
                IstZahl = true,
                BreitenAnteil = breitenAnteil
            });
            return this;
        }

        public TabelleBlock Zeile(params object[] werte)
        {
            Zeilen.Add(werte);
            return this;
        }

        public TabelleBlock Zeilen<T>(IEnumerable<T> quelle, Func<T, object[]> abbildung)
        {
            if (quelle != null)
                foreach (T e in quelle)
                    Zeilen.Add(abbildung(e));
            return this;
        }

        public TabelleBlock MitSummenzeile()
        {
            SummenzeileAnzeigen = true;
            return this;
        }
    }

    public class Spalte
    {
        public string Ueberschrift;
        public Ausrichtung Ausrichtung = Ausrichtung.Links;
        public string Format;          // .NET-Formatstring, nur bei IstZahl
        public string Einheit;
        public bool   IstZahl;
        public double BreitenAnteil = 1.0;
    }

    public class DiagrammBlock : ReportBlock
    {
        public string ChartName;       // Schluessel im Chart-Katalog
        public string Beschriftung;
        public double BreiteAnteil = 1.0;
        public string BildDatei;       // wird vom ChartImageProvider vor dem Rendern gesetzt
    }

    public class AufzaehlungBlock : ReportBlock
    {
        public List<string> Punkte = new List<string>();
        public bool Nummeriert;
    }

    public class SeitenumbruchBlock : ReportBlock { }
}
