using System;
using System.Threading;
using WindowsFormsApplication1.Reporting.Dokument;

namespace WindowsFormsApplication1.Reporting.Renderer
{
    // ---------------------------------------------------------------------------
    // Die Schnittstelle, die das Konzept zusammenhaelt.
    //
    // Sie sorgt dafuer, dass
    //   - ein Wechsel der PDF-Bibliothek (QuestPDF <-> PDFsharp/MigraDoc) nur diesen
    //     einen Renderer trifft und nie die Bausteine,
    //   - mehrere Formate in einem Lauf aus DEMSELBEN ReportDocument entstehen,
    //   - Bausteine testbar bleiben, ohne dass eine Datei erzeugt werden muss.
    //
    // Angesichts der Lizenzwechsel der letzten Jahre (EPPlus, NPOI, ImageSharp,
    // QuestPDF) ist diese Entkopplung kein Selbstzweck.
    // ---------------------------------------------------------------------------

    public interface IReportRenderer
    {
        /// <summary>Anzeigename, z.B. "PDF".</summary>
        string Name { get; }

        /// <summary>Mit fuehrendem Punkt, z.B. ".pdf".</summary>
        string Dateiendung { get; }

        /// <summary>Prueft Voraussetzungen (Bibliothek geladen, Lizenz gesetzt,
        /// Schriften verfuegbar). Verhindert, dass der Anwender ein Format waehlen
        /// kann, das anschliessend mit einer Bibliotheksausnahme abbricht.</summary>
        bool IstVerfuegbar(out string grund);

        void Rendere(ReportDocument doc,
                     ReportTheme theme,
                     string zielDatei,
                     IProgress<ReportFortschritt> fortschritt,
                     CancellationToken abbruch);
    }

    public class ReportFortschritt
    {
        public string Schritt;
        public int    Erledigt;
        public int    Gesamt;

        public ReportFortschritt(string schritt, int erledigt = 0, int gesamt = 0)
        {
            Schritt  = schritt;
            Erledigt = erledigt;
            Gesamt   = gesamt;
        }

        public double Anteil => Gesamt > 0 ? (double)Erledigt / Gesamt : 0.0;
    }

    public class ReportErgebnis
    {
        public bool     Erfolg;
        public string   ZielDatei;
        public string   Fehlertext;
        public string[] FelderOhneWert;   // fuer das Protokoll: was war im Bericht "—"?
        public TimeSpan Dauer;

        public static ReportErgebnis Ok(string datei, string[] ohneWert, TimeSpan dauer)
            => new ReportErgebnis
            {
                Erfolg = true, ZielDatei = datei,
                FelderOhneWert = ohneWert ?? new string[0], Dauer = dauer
            };

        public static ReportErgebnis Fehler(string text)
            => new ReportErgebnis { Erfolg = false, Fehlertext = text };
    }
}
